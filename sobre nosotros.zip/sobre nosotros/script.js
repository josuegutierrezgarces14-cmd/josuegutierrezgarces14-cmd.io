/* =========================================================
   DE ENSUEÑO
   SCRIPT GENERAL
========================================================= */


/* =========================================================
   PRODUCTOS
========================================================= */

const products = [

    {
        id: 1,
        name: "Producto 1",
        category: "hogar",
        price: 25000,
        image: "r1.png",
        description: "Producto práctico y moderno, pensado para facilitar diferentes actividades del día a día."
    },

    {
        id: 2,
        name: "Producto 2",
        category: "accesorios",
        price: 38000,
        image: "r2.png",
        description: "Una opción moderna y funcional, con un diseño sencillo y fácil de utilizar."
    },

    {
        id: 3,
        name: "Producto 3",
        category: "tecnologia",
        price: 55000,
        image: "r3.png",
        description: "Producto con diseño moderno y características pensadas para ofrecer una buena experiencia."
    },

    {
        id: 4,
        name: "Producto 4",
        category: "hogar",
        price: 42000,
        image: "r4.png",
        description: "Una alternativa práctica y sencilla para utilizar en diferentes situaciones."
    },

    {
        id: 5,
        name: "Producto 5",
        category: "accesorios",
        price: 29000,
        image: "r5.png",
        description: "Producto versátil y moderno que se adapta fácilmente a diferentes necesidades."
    },

    {
        id: 6,
        name: "Producto 6",
        category: "tecnologia",
        price: 79000,
        image: "r6.png",
        description: "Una opción especial con un diseño moderno, práctico y funcional."
    },

    {
        id: 7,
        name: "Producto 7",
        category: "hogar",
        price: 35000,
        image: "Imagenes/r7.png",
        description: "Una opción pensada para darle funcionalidad y estilo a tus espacios."
    },

    {
        id: 8,
        name: "Producto 8",
        category: "accesorios",
        price: 45000,
        image: "Imagenes/r8.png",
        description: "Un complemento moderno y versátil para diferentes ocasiones."
    },

    {
        id: 9,
        name: "Producto 9",
        category: "tecnologia",
        price: 68000,
        image: "Imagenes/r9.png",
        description: "Tecnología práctica para acompañar tus necesidades del día a día."
    },

    {
        id: 10,
        name: "Producto 10",
        category: "hogar",
        price: 52000,
        image: "Imagenes/r10.png",
        description: "Una alternativa para complementar y mejorar tus espacios."
    },

    {
        id: 11,
        name: "Producto 11",
        category: "accesorios",
        price: 61000,
        image: "Imagenes/r11.png",
        description: "Un complemento pensado para combinar funcionalidad y estilo."
    },

    {
        id: 12,
        name: "Producto 12",
        category: "tecnologia",
        price: 85000,
        image: "Imagenes/r12.png",
        description: "Una opción tecnológica para quienes buscan algo práctico y funcional."
    },


    {
        id: 13,
        name: "Producto 13",
        category: "hogar",
        price: 25000,
        image: "r1.png",
        description: "Producto práctico y moderno, pensado para facilitar diferentes actividades del día a día."
    },

    {
        id: 14,
        name: "Producto 14",
        category: "accesorios",
        price: 38000,
        image: "r2.png",
        description: "Una opción moderna y funcional, con un diseño sencillo y fácil de utilizar."
    },

    {
        id: 15,
        name: "Producto 15",
        category: "tecnologia",
        price: 55000,
        image: "r3.png",
        description: "Producto con diseño moderno y características pensadas para ofrecer una buena experiencia."
    },

    {
        id: 16,
        name: "Producto 16",
        category: "hogar",
        price: 42000,
        image: "r4.png",
        description: "Una alternativa práctica y sencilla para utilizar en diferentes situaciones."
    },

    {
        id: 17,
        name: "Producto 17",
        category: "accesorios",
        price: 29000,
        image: "r5.png",
        description: "Producto versátil y moderno que se adapta fácilmente a diferentes necesidades."
    },

    {
        id: 18,
        name: "Producto 18",
        category: "tecnologia",
        price: 79000,
        image: "r6.png",
        description: "Una opción especial con un diseño moderno, práctico y funcional."
    },

    {
        id: 19,
        name: "Producto 19",
        category: "hogar",
        price: 35000,
        image: "Imagenes/r7.png",
        description: "Una opción pensada para darle funcionalidad y estilo a tus espacios."
    },

    {
        id: 20,
        name: "Producto 20",
        category: "accesorios",
        price: 45000,
        image: "Imagenes/r8.png",
        description: "Un complemento moderno y versátil para diferentes ocasiones."
    },

    {
        id: 21,
        name: "Producto 21",
        category: "tecnologia",
        price: 68000,
        image: "Imagenes/r9.png",
        description: "Tecnología práctica para acompañar tus necesidades del día a día."
    },

    {
        id: 22,
        name: "Producto 22",
        category: "hogar",
        price: 52000,
        image: "Imagenes/r10.png",
        description: "Una alternativa para complementar y mejorar tus espacios."
    },

    {
        id: 23,
        name: "Producto 23",
        category: "accesorios",
        price: 61000,
        image: "Imagenes/r11.png",
        description: "Un complemento pensado para combinar funcionalidad y estilo."
    },

    {
        id: 24,
        name: "Producto 24",
        category: "tecnologia",
        price: 85000,
        image: "Imagenes/r12.png",
        description: "Una opción tecnológica para quienes buscan algo práctico y funcional."
    },

    {
        id: 25,
        name: "Producto 25",
        category: "hogar",
        price: 25000,
        image: "r1.png",
        description: "Producto práctico y moderno, pensado para facilitar diferentes actividades del día a día."
    },

    {
        id: 26,
        name: "Producto 26",
        category: "accesorios",
        price: 38000,
        image: "r2.png",
        description: "Una opción moderna y funcional, con un diseño sencillo y fácil de utilizar."
    },

    {
        id: 27,
        name: "Producto 27",
        category: "tecnologia",
        price: 55000,
        image: "r3.png",
        description: "Producto con diseño moderno y características pensadas para ofrecer una buena experiencia."
    },

    {
        id: 28,
        name: "Producto 28",
        category: "hogar",
        price: 42000,
        image: "r4.png",
        description: "Una alternativa práctica y sencilla para utilizar en diferentes situaciones."
    },

    {
        id: 29,
        name: "Producto 29",
        category: "accesorios",
        price: 29000,
        image: "r5.png",
        description: "Producto versátil y moderno que se adapta fácilmente a diferentes necesidades."
    },

    {
        id: 30,
        name: "Producto 30",
        category: "tecnologia",
        price: 79000,
        image: "r6.png",
        description: "Una opción especial con un diseño moderno, práctico y funcional."
    },

    {
        id: 31,
        name: "Producto 31",
        category: "hogar",
        price: 35000,
        image: "Imagenes/r7.png",
        description: "Una opción pensada para darle funcionalidad y estilo a tus espacios."
    },

    {
        id: 32,
        name: "Producto 32",
        category: "accesorios",
        price: 45000,
        image: "Imagenes/r8.png",
        description: "Un complemento moderno y versátil para diferentes ocasiones."
    },

    {
        id: 33,
        name: "Producto 33",
        category: "tecnologia",
        price: 68000,
        image: "Imagenes/r9.png",
        description: "Tecnología práctica para acompañar tus necesidades del día a día."
    },

    {
        id: 34,
        name: "Producto 34",
        category: "hogar",
        price: 52000,
        image: "Imagenes/r10.png",
        description: "Una alternativa para complementar y mejorar tus espacios."
    },

    {
        id: 35,
        name: "Producto 35",
        category: "accesorios",
        price: 61000,
        image: "Imagenes/r11.png",
        description: "Un complemento pensado para combinar funcionalidad y estilo."
    },

    {
        id: 36,
        name: "Producto 36",
        category: "tecnologia",
        price: 85000,
        image: "Imagenes/r12.png",
        description: "Una opción tecnológica para quienes buscan algo práctico y funcional."
    },


    {
        id: 37,
        name: "Producto 37",
        category: "hogar",
        price: 25000,
        image: "r1.png",
        description: "Producto práctico y moderno, pensado para facilitar diferentes actividades del día a día."
    },

    {
        id: 38,
        name: "Producto 38",
        category: "accesorios",
        price: 38000,
        image: "r2.png",
        description: "Una opción moderna y funcional, con un diseño sencillo y fácil de utilizar."
    },

    {
        id: 39,
        name: "Producto 39",
        category: "tecnologia",
        price: 55000,
        image: "r3.png",
        description: "Producto con diseño moderno y características pensadas para ofrecer una buena experiencia."
    },

    {
        id: 40,
        name: "Producto 40",
        category: "hogar",
        price: 42000,
        image: "r4.png",
        description: "Una alternativa práctica y sencilla para utilizar en diferentes situaciones."
    },

    {
        id: 41,
        name: "Producto 41",
        category: "accesorios",
        price: 29000,
        image: "r5.png",
        description: "Producto versátil y moderno que se adapta fácilmente a diferentes necesidades."
    },

    {
        id: 42,
        name: "Producto 42",
        category: "tecnologia",
        price: 79000,
        image: "r6.png",
        description: "Una opción especial con un diseño moderno, práctico y funcional."
    },

    {
        id: 43,
        name: "Producto 43",
        category: "hogar",
        price: 35000,
        image: "Imagenes/r7.png",
        description: "Una opción pensada para darle funcionalidad y estilo a tus espacios."
    },

    {
        id: 44,
        name: "Producto 44",
        category: "accesorios",
        price: 45000,
        image: "Imagenes/r8.png",
        description: "Un complemento moderno y versátil para diferentes ocasiones."
    },

    {
        id: 45,
        name: "Producto 45",
        category: "tecnologia",
        price: 68000,
        image: "Imagenes/r9.png",
        description: "Tecnología práctica para acompañar tus necesidades del día a día."
    },

    {
        id: 46,
        name: "Producto 46",
        category: "hogar",
        price: 52000,
        image: "Imagenes/r10.png",
        description: "Una alternativa para complementar y mejorar tus espacios."
    },

    {
        id: 47,
        name: "Producto 47",
        category: "accesorios",
        price: 61000,
        image: "Imagenes/r11.png",
        description: "Un complemento pensado para combinar funcionalidad y estilo."
    },

    {
        id: 48,
        name: "Producto 48",
        category: "tecnologia",
        price: 85000,
        image: "Imagenes/r12.png",
        description: "Una opción tecnológica para quienes buscan algo práctico y funcional."
    },

    {
        id: 49,
        name: "Producto 49",
        category: "hogar",
        price: 52000,
        image: "Imagenes/r10.png",
        description: "Una alternativa para complementar y mejorar tus espacios."
    },

    {
        id: 50,
        name: "Producto 50",
        category: "accesorios",
        price: 61000,
        image: "Imagenes/r11.png",
        description: "Un complemento pensado para combinar funcionalidad y estilo."
    },

    {
        id: 51,
        name: "Producto 51",
        category: "tecnologia",
        price: 85000,
        image: "Imagenes/r12.png",
        description: "Una opción tecnológica para quienes buscan algo práctico y funcional."
    }

];


/* =========================================================
FORMATO DE PRECIOS
========================================================= */

function formatPrice(price) {

    return new Intl.NumberFormat("es-CO", {
        style: "currency",
        currency: "COP",
        maximumFractionDigits: 0
    }).format(price);

}


/* =========================================================
   CARRITO - LOCAL STORAGE
========================================================= */

const CART_KEY = "deEnsueñoCart";


function getCart() {

    try {

        return JSON.parse(
            localStorage.getItem(CART_KEY)
        ) || [];

    } catch (error) {

        console.error("Error leyendo el carrito:", error);

        return [];

    }

}


function saveCart(cart) {

    localStorage.setItem(
        CART_KEY,
        JSON.stringify(cart)
    );

}


/* =========================================================
   CONTADOR DEL CARRITO
========================================================= */

function updateCartCount() {

    const cart = getCart();

    const totalQuantity = cart.reduce(
        (total, item) => total + item.quantity,
        0
    );


    const counters = document.querySelectorAll(
        "#cart-count"
    );


    counters.forEach(counter => {

        counter.textContent = totalQuantity;

    });

}


/* =========================================================
   AGREGAR PRODUCTO
========================================================= */

function addToCart(productId, quantity = 1) {

    const product = products.find(
        item => item.id === Number(productId)
    );


    if (!product) {

        console.error("Producto no encontrado:", productId);

        return;

    }


    const cart = getCart();


    const existingProduct = cart.find(
        item => item.id === product.id
    );


    if (existingProduct) {

        existingProduct.quantity += Number(quantity);

    } else {

        cart.push({

            id: product.id,

            name: product.name,

            category: product.category,

            price: product.price,

            image: product.image,

            description: product.description,

            quantity: Number(quantity)

        });

    }


    saveCart(cart);

    updateCartCount();


    // Mensaje sencillo

    const message = document.getElementById(
        "checkout-message"
    );


    if (message) {

        message.textContent =
            `${product.name} fue agregado al carrito.`;

        setTimeout(() => {

            message.textContent = "";

        }, 2500);

    } else {

        alert(
            `${product.name} fue agregado al carrito.`
        );

    }

}


/* =========================================================
   RENDERIZAR PRODUCTOS
========================================================= */

function renderProducts(list = products) {

    const container =
        document.querySelector("#products-container") ||
        document.querySelector("#products-grid") ||
        document.querySelector("#productsContainer");


    if (!container) return;


    if (list.length === 0) {

        container.innerHTML = `

            <div class="no-products">

                <h3>No encontramos productos</h3>

                <p>
                    Intenta cambiar la búsqueda o los filtros.
                </p>

            </div>

        `;

        return;

    }


    container.innerHTML = list.map(product => `

        <article class="product-card">

            <div class="product-image">

                <img
                    src="${product.image}"
                    alt="${product.name}"
                    onerror="this.onerror=null; this.src='Imagenes/r${product.id}.png';"
                >

            </div>


            <div class="product-info">

                <span class="product-category">
                    ${capitalizeCategory(product.category)}
                </span>

                <h3>
                    ${product.name}
                </h3>

                <p>
                    ${product.description}
                </p>

                <strong class="product-price">
                    ${formatPrice(product.price)}
                </strong>


                <div class="product-buttons">

                    <a
                        href="producto${product.id}.html"
                        class="btn-product btn-view"
                    >
                        Ver producto
                    </a>


                    <button
                        type="button"
                        class="btn-product btn-add"
                        onclick="addToCart(${product.id})"
                    >
                        Agregar
                    </button>

                </div>

            </div>

        </article>

    `).join("");

}


/* =========================================================
   CATEGORÍA
========================================================= */

function capitalizeCategory(category) {

    if (!category) return "";

    return category.charAt(0).toUpperCase()
        + category.slice(1);

}


/* =========================================================
   PÁGINA DE PRODUCTOS
========================================================= */

function initProductsPage() {

    const searchInput =
        document.querySelector("#searchInput") ||
        document.querySelector("#search") ||
        document.querySelector("#product-search");


    const categoryFilter =
        document.querySelector("#categoryFilter") ||
        document.querySelector("#category-filter") ||
        document.querySelector("#category");


    const sortSelect =
        document.querySelector("#sortProducts") ||
        document.querySelector("#sort") ||
        document.querySelector("#sort-products");


    const resultCount =
        document.querySelector("#resultCount") ||
        document.querySelector("#result-count");


    const container =
        document.querySelector("#products-container") ||
        document.querySelector("#products-grid") ||
        document.querySelector("#productsContainer");


    if (!container) return;


    function applyFilters() {

        let filteredProducts = [...products];


        /* BUSCADOR */

        const search = searchInput
            ? searchInput.value.trim().toLowerCase()
            : "";


        if (search) {

            filteredProducts =
                filteredProducts.filter(product =>

                    product.name
                        .toLowerCase()
                        .includes(search)

                    ||

                    product.description
                        .toLowerCase()
                        .includes(search)

                    ||

                    product.category
                        .toLowerCase()
                        .includes(search)

                );

        }


        /* CATEGORÍA */

        const category =
            categoryFilter
                ? categoryFilter.value
                : "all";


        if (
            category &&
            category !== "all" &&
            category !== "todos"
        ) {

            filteredProducts =
                filteredProducts.filter(
                    product =>
                        product.category === category
                );

        }


        /* ORDEN */

        const sort =
            sortSelect
                ? sortSelect.value
                : "default";


        if (
            sort === "price-low" ||
            sort === "price-asc"
        ) {

            filteredProducts.sort(
                (a, b) => a.price - b.price
            );

        }


        else if (
            sort === "price-high" ||
            sort === "price-desc"
        ) {

            filteredProducts.sort(
                (a, b) => b.price - a.price
            );

        }


        else if (
            sort === "name" ||
            sort === "name-asc"
        ) {

            filteredProducts.sort(
                (a, b) =>
                    a.name.localeCompare(
                        b.name,
                        "es"
                    )
            );

        }


        renderProducts(filteredProducts);


        /* CONTADOR */

        if (resultCount) {

            resultCount.textContent =
                `${filteredProducts.length} producto(s)`;

        }

    }


    if (searchInput) {

        searchInput.addEventListener(
            "input",
            applyFilters
        );

    }


    if (categoryFilter) {

        categoryFilter.addEventListener(
            "change",
            applyFilters
        );

    }


    if (sortSelect) {

        sortSelect.addEventListener(
            "change",
            applyFilters
        );

    }


    applyFilters();

}


/* =========================================================
   PÁGINA DE PRODUCTO INDIVIDUAL
========================================================= */

function initProductDetail() {

    const params = new URLSearchParams(
        window.location.search
    );


    const productId = Number(
        params.get("id")
    );


    if (!productId) return;


    const product = products.find(
        item => item.id === productId
    );


    if (!product) {

        console.error(
            "No existe el producto:",
            productId
        );

        return;

    }


    const name =
        document.querySelector("#product-name");

    const image =
        document.querySelector("#product-image");

    const description =
        document.querySelector("#product-description");

    const price =
        document.querySelector("#product-price");

    const quantity =
        document.querySelector("#product-quantity");


    if (name) {

        name.textContent =
            product.name;

    }


    if (image) {

        image.src =
            product.image;

        image.alt =
            product.name;

        image.onerror = function() {
            this.onerror = null;
            this.src = `Imagenes/r${product.id}.png`;
        };

    }


    if (description) {

        description.textContent =
            product.description;

    }


    if (price) {

        price.textContent =
            formatPrice(product.price);

    }


    if (quantity) {

        quantity.value = 1;

    }


    /* BOTÓN MENOS */

    const minusButton =
        document.querySelector("#quantity-minus");


    if (minusButton) {

        minusButton.addEventListener(
            "click",
            () => {

                let value =
                    Number(quantity.value) || 1;


                if (value > 1) {

                    value--;

                }


                quantity.value = value;

            }
        );

    }


    /* BOTÓN MÁS */

    const plusButton =
        document.querySelector("#quantity-plus");


    if (plusButton) {

        plusButton.addEventListener(
            "click",
            () => {

                let value =
                    Number(quantity.value) || 1;


                value++;


                quantity.value = value;

            }
        );

    }


    /* AGREGAR */

    const addButton =
        document.querySelector("#add-to-cart");


    if (addButton) {

        addButton.addEventListener(
            "click",
            () => {

                const amount =
                    Math.max(
                        1,
                        Number(quantity.value) || 1
                    );


                addToCart(
                    product.id,
                    amount
                );

            }
        );

    }

}


/* =========================================================
   RENDERIZAR CARRITO
========================================================= */

function renderCart() {
    const cartContainer = document.getElementById("cart-items");

    if (!cartContainer) return;

    const cart = getCart();

    if (cart.length === 0) {
        cartContainer.innerHTML = `
            <div class="empty-cart">
                <div class="empty-cart-icon">🛒</div>
                <h3>Tu carrito está vacío</h3>
                <p>Aún no has agregado productos.</p>
                <a href="productos.html" class="btn-product btn-view">
                    Ver productos
                </a>
            </div>
        `;

        updateCartTotals(0);
        updateCartCount();
        return;
    }

    cartContainer.innerHTML = cart.map(item => {
        // Buscar los datos originales del producto
        const product = products.find(
            p => Number(p.id) === Number(item.id)
        );

        if (!product) return "";

        const quantity = Number(item.quantity) || 1;
        const price = Number(product.price) || 0;
        const subtotal = price * quantity;

        // Usar la imagen original del producto
        const image = product.image;

        return `
            <article class="cart-item">

                <div class="cart-item-image">
                    <img
                        src="${image}"
                        alt="${product.name}"
                        onerror="this.onerror=null; this.src='Imagenes/r${product.id}.png';"
                    >
                </div>

                <div class="cart-item-info">
                    <span class="cart-item-category">
                        ${product.category || "Producto"}
                    </span>

                    <h3>${product.name}</h3>

                    <p>
                        ${product.description || ""}
                    </p>

                    <div class="cart-item-price">
                        ${formatPrice(price)}
                    </div>

                    <p class="cart-item-subtotal">
                        Subtotal: ${formatPrice(subtotal)}
                    </p>
                </div>

                <div class="cart-item-controls">

                    <div class="quantity-control">
                        <button
                            type="button"
                            onclick="changeQuantity(${product.id}, -1)"
                            aria-label="Disminuir cantidad"
                        >−</button>

                        <span>${quantity}</span>

                        <button
                            type="button"
                            onclick="changeQuantity(${product.id}, 1)"
                            aria-label="Aumentar cantidad"
                        >+</button>
                    </div>

                    <button
                        type="button"
                        class="remove-item"
                        onclick="removeFromCart(${product.id})"
                    >
                        Eliminar
                    </button>

                </div>

            </article>
        `;
    }).join("");

    const total = cart.reduce(
        (sum, item) => sum + (item.price * item.quantity),
        0
    );

    updateCartTotals(total);
    updateCartCount();
}


/* =========================================================
   ACTUALIZAR TOTALES
========================================================= */

function updateCartTotals(total) {

    const subtotal =
        document.querySelector("#cart-subtotal");


    const cartTotal =
        document.querySelector("#cart-total");


    if (subtotal) {

        subtotal.textContent =
            formatPrice(total);

    }


    if (cartTotal) {

        cartTotal.textContent =
            formatPrice(total);

    }


    /* CANTIDAD DE PRODUCTOS */

    const cart =
        getCart();


    const quantity =
        cart.reduce(
            (sum, item) =>
                sum + item.quantity,
            0
        );


    const itemsCount =
        document.querySelector(
            "#cart-items-count"
        );


    if (itemsCount) {

        itemsCount.textContent =
            quantity;

    }


    updateCartCount();

}


/* =========================================================
   CAMBIAR CANTIDAD
========================================================= */

function changeQuantity(productId, change) {

    const cart = getCart();


    const item = cart.find(
        product =>
            product.id === Number(productId)
    );


    if (!item) return;


    item.quantity += Number(change);


    if (item.quantity <= 0) {

        const newCart =
            cart.filter(
                product =>
                    product.id !== Number(productId)
            );


        saveCart(newCart);

    } else {

        saveCart(cart);

    }


    renderCart();

}


/* =========================================================
   ELIMINAR PRODUCTO
========================================================= */

function removeFromCart(productId) {

    const cart = getCart();


    const newCart =
        cart.filter(
            item =>
                item.id !== Number(productId)
        );


    saveCart(newCart);


    renderCart();


    updateCartCount();

}


/* =========================================================
   MÉTODO DE PAGO
========================================================= */

function initPayment() {

    const paymentOptions =
        document.querySelectorAll(
            'input[name="payment"]'
        );


    const nequiInfo =
        document.querySelector(
            "#nequi-info"
        );


    if (
        !paymentOptions.length ||
        !nequiInfo
    ) {

        return;

    }


    function updatePaymentInfo() {

        const selected =
            document.querySelector(
                'input[name="payment"]:checked'
            );


        if (
            selected &&
            selected.value === "Nequi"
        ) {

            nequiInfo.style.display =
                "block";

        } else {

            nequiInfo.style.display =
                "none";

        }

    }


    paymentOptions.forEach(
        option => {

            option.addEventListener(
                "change",
                updatePaymentInfo
            );

        }
    );


    updatePaymentInfo();

}


/* =========================================================
   CONFIRMAR PEDIDO
========================================================= */

function confirmOrder() {

    const cart = getCart();


    if (cart.length === 0) {

        alert(
            "Tu carrito está vacío."
        );

        return;

    }


    const name =
        document.querySelector(
            "#customer-name"
        )?.value.trim();


    const phone =
        document.querySelector(
            "#customer-phone"
        )?.value.trim();


    const address =
        document.querySelector(
            "#customer-address"
        )?.value.trim();


    const payment =
        document.querySelector(
            'input[name="payment"]:checked'
        )?.value;


    /* VALIDAR */

    if (!name) {

        alert(
            "Por favor escribe tu nombre."
        );

        return;

    }


    if (!phone) {

        alert(
            "Por favor escribe tu número de teléfono."
        );

        return;

    }


    if (!address) {

        alert(
            "Por favor escribe tu dirección."
        );

        return;

    }


    if (!payment) {

        alert(
            "Selecciona un método de pago."
        );

        return;

    }


    /* PRODUCTOS */

    let productsMessage = "";


    cart.forEach(item => {

        const subtotal =
            item.price * item.quantity;


        productsMessage +=
            `• ${item.name} x${item.quantity} - ${formatPrice(subtotal)}\n`;

    });


    /* TOTAL */

    const total =
        cart.reduce(
            (sum, item) =>
                sum +
                (item.price * item.quantity),
            0
        );


    /* MENSAJE */

    const message =

`Hola, quiero realizar un pedido en DE ENSUEÑO.

👤 DATOS DEL CLIENTE
Nombre: ${name}
Teléfono: ${phone}
Dirección: ${address}

🛍 PRODUCTOS
${productsMessage}
💰 TOTAL PRODUCTOS: ${formatPrice(total)}

🚚 ENVÍO:
El costo del envío se coordina aparte.

💳 MÉTODO DE PAGO:
${payment}

Quedo atento(a) para confirmar los detalles del pedido.`;


    /* NÚMERO DE WHATSAPP */

    const whatsappNumber =
        "573214396587";


    const whatsappURL =
        `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;


    /* ABRIR WHATSAPP */

    window.open(
        whatsappURL,
        "_blank"
    );


    /* MENSAJE EN PÁGINA */

    const checkoutMessage =
        document.querySelector(
            "#checkout-message"
        );


    if (checkoutMessage) {

        checkoutMessage.textContent =
            "Tu pedido está siendo enviado por WhatsApp.";

    }

}


/* =========================================================
   MENÚ HAMBURGUESA
========================================================= */

function initMenu() {

    const menuToggle =
        document.querySelector(
            "#menu-toggle"
        );


    const navLinks =
        document.querySelectorAll(
            ".nav-menu a"
        );


    if (!menuToggle) return;


    /* Cerrar menú al seleccionar una opción */

    navLinks.forEach(link => {

        link.addEventListener(
            "click",
            () => {

                menuToggle.checked = false;

            }
        );

    });

}


/* =========================================================
   CERRAR MENÚ AL HACER CLICK AFUERA
========================================================= */

function closeMenuOutside() {

    const menuToggle =
        document.querySelector(
            "#menu-toggle"
        );


    const menuContainer =
        document.querySelector(
            ".menu-container"
        );


    if (
        !menuToggle ||
        !menuContainer
    ) {

        return;

    }


    document.addEventListener(
        "click",
        event => {

            if (
                menuToggle.checked &&
                !menuContainer.contains(
                    event.target
                )
            ) {

                menuToggle.checked = false;

            }

        }
    );

}


/* =========================================================
   INICIALIZACIÓN
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        /* Contador */

        updateCartCount();


        /* Página de productos */

        initProductsPage();


        /* Producto individual */

        initProductDetail();


        /* Carrito */

        renderCart();


        /* Pagos */

        initPayment();


        /* Menú */

        initMenu();

        closeMenuOutside();


        /* Botón confirmar */

        const confirmButton =
            document.querySelector(
                "#confirm-order"
            );


        if (confirmButton) {

            confirmButton.addEventListener(
                "click",
                confirmOrder
            );

        }

    }
);